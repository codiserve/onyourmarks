---
title: Algolia search
tags: [formatting]
keywords: search
summary: "This page demonstrates an integration of Algolia search."
---

## algolia:

{% include algolia.html %}