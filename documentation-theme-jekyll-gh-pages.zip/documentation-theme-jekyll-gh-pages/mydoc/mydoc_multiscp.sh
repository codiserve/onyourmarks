scp -r /Applications/XAMPP/xamppfiles/htdocs/documentation-theme-jekyll/writers name@domain:/var/www/html/documentation-theme-jekyll/writers
echo "All done."

